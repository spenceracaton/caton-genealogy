# Caton genealogy evidence

See the accompanying handoff, sections 11 and 18.

These scans document Thomas Caton’s 1830 household and Joseph Caton’s occupation and family. None names Aaron’s parents. The handoff includes transcription, interpretation, limitations, and next records to pursue.

The download endpoint index differs from original leaf metadata in the printed books. URLs in sources.json reproduce the exact verified images.
