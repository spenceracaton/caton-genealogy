# Caton Genealogy Research — Living Handoff

**Last updated:** 9 September 2026 — second research pass; see current status below  

> **Current status:** Aaron’s parents remain unknown. New primary evidence identifies **Thomas Caton** as the 1830 Ohio County p. 209 head. Its boy is aged 5–9, not the expected 10–14. Joseph Caton’s family is now supported by an inspected 1898 biography. See sections 11 and 18. Earlier unsourced assertions remain inherited research notes unless explicitly verified here.

**Primary research question:** Who were the parents of **Aaron Caton**, born 16 May 1820, reportedly in Wheeling, Virginia (now West Virginia)?

This file is intended to be the durable state for continuing the research in a fresh ChatGPT thread without carrying the entire conversation. Treat it as a research ledger: preserve proven facts, keep hypotheses explicitly labeled, and do not merge online trees without corroboration.

---

## 1. Confirmed direct line

Spencer Caton  
→ Philip Brettun Caton (b. 1950)  
→ Chandler Maynard Caton (1912–2002)  
→ Louis Merrill Caton (1886–1970)  
→ William Bramwell Caton (1847–1941)  
→ **Aaron Caton (b. 16 May 1820; parents unknown)**

### William Bramwell Caton
- Born 1847 in Delaware County, Ohio.
- Father: Aaron Caton.
- Later lived in Missouri and Winfield, Kansas.
- Civil War-era material and later biography associate him directly with Aaron.
- Founded Caton Marble Works in Winfield.

### Aaron Caton
High-confidence facts:
- Born 16 May 1820; later sources report Wheeling, Virginia.
- Married **Sarah Ann Gardner** in Delaware County, Ohio:
  - license 7 Aug 1841
  - marriage 8 Aug 1841
- Occupation: **tailor**.
- About 40–41 in 1861.
- Enlisted at Chillicothe, Missouri, 7 Sep 1861.
- Company E, 2nd Missouri Volunteer Cavalry / Merrill's Horse.
- Gave written consent for underage son William to enlist.
- Exact death remains unconfirmed.
- A widely repeated date, 11 Jan 1878 in Boonville/Cooper County, Missouri, remains **unproven**.

Important source:
- James W. Erwin, *Guerrilla Hunters in Civil War Missouri* (2013).
- Erwin's sources point to NARA RG 94, Compiled Service Records of Missouri Union Volunteers, microfilm M405.
- Aaron's full military file remains a high-priority target.

---

## 2. Major false merges — DO NOT COMBINE

### Aaron F. Caton of Cooper County
Different man.
1850 Cooper County household:
- William Caton, 38, Virginia
- John W., 18
- Aaron F., 8
- Sarah Ann, 6
- Elizabeth, 4
- Wingfield, 2

Aaron F.:
- born c.1839/42 Missouri
- married Emeline O'Neal
- died 16 Jan 1886 near Otterville in railroad accident
- buried Otterville IOOF Cemetery

### Andrew Caton / New York line
Different Caton family.
- Andrew born 1822 New York.
- Raised in Seneca County, New York; later central Ohio.
- **Emma J. Caton of Delaware County, Ohio, was Andrew's daughter**, not Aaron's. This was independently clarified through a Delaware County biography.
- Do not use Emma as evidence for Aaron.

### Jesse Caton / Warren-Linn County Missouri line
Older Missouri family:
- Jesse Caton from Kentucky settled near Marthasville in 1811.
- Known children include Noah, Jonas, Jesse Jr., Elizabeth, Nancy, Jemima, Mahala, Rebecca, Fannie, Hester.
- Linn County Catons found in the 1860-era search belong to this cluster; e.g. Jonas Caton died intestate in 1859 with Luther T. Caton administrator, and Noah Caton appears there.
- No evidence yet that Aaron belongs to this family.

---

## 3. Alfred Caton hypothesis

### Alfred Caton
Working profile:
- born 29 Jan 1805
- birthplace often given as Leesburg, Virginia; some compiled records mislabel it Leesburg, Maryland
- married Sarah Chaddock/Chadduck in Ohio County, Virginia, 1828
- lived in Wheeling / Belmont County, Ohio region in 1830s
- later Missouri
- died reportedly 9 Nov 1889, but exact death county is still not independently established
- children include Charles Caton, John Harrison Caton (b. 1838 Belmont County), Melinda J. Caton

Why Alfred matters:
- His reported birth date makes him 15 at Aaron’s birth. Fatherhood is possible but less likely; age alone does not exclude it.
- He is geographically well placed to be an older brother, half-brother, uncle, or cousin.
- His family occupied the Wheeling/Belmont region during Aaron's childhood.
- He later migrated to Missouri.

### George/Jemima claim — DOWNGRADED
Compiled trees identify Alfred's parents as:
- George Thomas Caton
- Jemima Prall VanKirk-Caton

Do **not** accept this.

Independent Washington County, Pennsylvania records prove a Thomas Caton + Susanna family whose children included:
- George Caton
- Milche Caton, wife of Thomas Praul/Prall
- Prescylla Caton, wife of Gideon VanKirk

Thus **Caton, Prall/Praul, and VanKirk genuinely occur in one family network**, but this creates a strong possibility that later tree-builders combined surnames from collateral relatives to create “Jemima Prall VanKirk.”

No independent record has yet been found proving:
- a Jemima Prall VanKirk married George Caton
- George was Alfred's father

Track the documented man simply as **George Caton, son of Thomas and Susanna**, unless a primary source supplies another name.

### Alfred probate
- Warren County probate index contains no Alfred Caton estate through 1900.
- Do not infer Warren County residence merely from the 1869 Melinda litigation.
- Montgomery and Lincoln counties remain probate/obituary targets.
- Reported Truxton/Lincoln County death is still compiled-tree evidence, not independently proven.

---

## 4. Thomas and Susanna Caton of Washington County, Pennsylvania

This is a **real, independently documented family**, but connection to Aaron is not proven.

- Thomas Caton died by 1795.
- Susanna is explicitly recorded as widow of Thomas Caton, late of Amwell Township, in an April 1795 record.
- 1808 estate partition names Thomas's widow Susanna and children, including **George Caton**.
- George is independently present in Amwell Township in 1803 on a road petition.
- Susanna Caton appears to have a separate Washington County estate/probate entry in 1825; the actual file remains a high-value target.

Research value:
- Washington County lies in the upper Ohio/Wheeling migration corridor.
- This family supplies a genuine George Caton and explains the Prall/VanKirk surnames.
- It is a plausible ancestral network, but **no bridge to Aaron or Alfred has yet been proven**.

---

## 5. 1820 Harrison County, Virginia lead

A significant census lead was developed, but it remains provisional.

### What was found
- The 1820 Ohio County, Virginia index appears to contain **no Caton household**, despite Aaron's reported Wheeling birth in May 1820.
- Alexander Gosney is present in the area; **Elizabeth Caton married Alexander Gosney in Ohio County in 1818**, proving Caton presence near Wheeling shortly before Aaron's birth.
- Harrison County, Virginia (now WV), roughly 70–90 miles southeast of Wheeling, has a CATON entry on page 88.

Comparison of two transcriptions/indexes suggests:
- independent page-88 index: CATON and CASTOE
- FamilySearch-derived/OCR transcription: **David “Caster”** and **Jane “Castoe”**
- This makes it highly plausible that “David Caster” is actually the indexed **David Caton**.

Provisional reconstructed David household:
- head: male 26–44
- female 26–44
- **two males under 10**
- **three females under 10**

Aaron, an infant in 1820, could fit one of the two boys.

### Important limitation
This is **not proof that David was Aaron's father**.
No later record has yet connected Aaron to David.

A Harrison-area Theophilus Caton born c.1804/05 married there in 1829, but David's 1820 household lacks a male aged 10–15, so Theophilus cannot simply be assumed to be an older son living in David's household.

### Bad submitted pedigree discarded
A submitted tree linked a Harrison John Caton to William Caton + Jane Hargreaves. Independent Lancashire evidence showed a James Hargreaves Caton marrying in Lancaster, England in 1812 with William Caton as witness. This strongly suggests a transatlantic tree merge. Do not use that pedigree.

---

## 6. Older Theophilus / Muskingum County cluster

A 1948 *Maryland Historical Magazine* genealogy query documents an older:
- **Theophilus Caton**
- in Washington County, Pennsylvania in 1800
- died Muskingum County, Ohio in 1825
- children reportedly included Theophilus Jr. and Greenberry Caton

Theophilus Jr. appears to be a different man from the Harrison County Theophilus born c.1804/05.

Greenberry Caton:
- born c.1793
- married in Muskingum County in 1811

This establishes another genuine PA→Ohio Caton migration corridor but has **not yet been connected to Aaron**.

---

## 7. George W. Caton — Missouri tailor lead

This is currently one of the most interesting FAN-club leads.

A **George W. Caton**, born about 1800 in Virginia:
- married Sarah H. Moore in Washington, D.C., in 1822
- was a **tailor**
- was established in Missouri by the early 1830s
- a Cooper County history places George W. Caton, tailor, in Boonville in the 1830–1840 period
- 1850 census: George W. Caton, age about 50, born Virginia, occupation tailor, in St. Clair County, Missouri
- children reportedly include George R. (born c.1828 Washington, D.C.) and **Nathan Thomas Caton** (born 1832 St. Louis)

Why he matters:
Aaron was also:
- Virginia-born
- a tailor
- later in Missouri

The combination of surname + Virginia origin + skilled trade + Missouri migration is more probative than surname/geography alone. Tailoring could have been learned through family/apprenticeship networks.

Aaron may also have had infant twin sons in 1853 named:
- Levi Andrew Caton
- **Aaron Nathan Caton**

These child names currently come from compiled/WikiTree-style material and require independent confirmation. If correct, the recurrence of **Nathan** alongside George W.'s son Nathan Thomas is suggestive, not proof.

### Important caution: multiple George W. Catons
A separate **George Wesley Caton** lived in Muskingum County, Ohio:
- married Mildred Buckley
- both described in an 1891 county biography as Virginia natives
- daughter Mildred Caton born Muskingum County in 1841
- George W. Caton's will appears in Muskingum County Will Book D, p. 553
- cemetery indexing places a Moses Caton (1767–1839) and George W. Caton (d. 1847) in the Roseville community

Do **not** merge the Missouri tailor George W. with the Muskingum George Wesley without evidence.

---

## 8. Joseph Caton — another Missouri tailor

A Chariton County history identifies **Joseph Caton as Brunswick's pioneer tailor**, established there around 1840; he was reportedly still living at Salisbury when the 1896 history was written.

This matters because there are now at least three Caton-tailor observations in Missouri:
1. George W. Caton — Boonville / later Missouri
2. Joseph Caton — Brunswick
3. Aaron Caton — Missouri, Civil War record

This could indicate a family occupational network, but Joseph's birthplace and parentage still need to be established before drawing conclusions.

**High-value task:** identify Joseph in 1850/1860/1870/1880 and find obituary/death record/biography naming his origin or relatives.

---

## 9. Aaron's Missouri geography

Do not reduce Aaron to “Chillicothe” simply because he enlisted there.

Known/strong clues:
- Aaron enlisted at **Chillicothe, Livingston County**, 7 Sep 1861.
- William's wartime story later places the family at/near **Sturgeon, Boone County, Missouri**; William was on a farm there in October 1862.
- A reported family move from Ohio to Missouri around **1858** has appeared in William-related biographical material and should be verified from the original text.
- Nearby Linn County Catons belong to the Jesse Caton cluster and should not be merged automatically.

The 1860 household remains a major missing record. Search should allow for:
- Caton / Catton / Caten / Cation / Eaton / Cason / OCR corruption
- Aaron as tailor
- wife Sarah
- son William, born 1847 Ohio
- other known/possible children
- Boone, Livingston, Chariton, Cooper and nearby counties

---

## 10. Elizabeth Caton Gosney

Potentially very important because she proves adult Caton presence in Ohio County just before Aaron's birth.

- Elizabeth Caton married **Alexander Gosney** in Ohio County, Virginia, 17 Dec 1818.
- An 1827 deed involving Alexander and Elizabeth Gosney may exist.
- Relationship to Aaron unknown.

Priority records:
- original 1818 marriage bond/license
- 1827 deed
- census trail
- probate/death records
- records naming parents/siblings

If Elizabeth proves to be a daughter of the same older Caton household that produced Aaron, she may be the bridge.

---

## 11. 1830 Ohio County census — IMAGE OBTAINED

The previously unidentified page-209 household is **Thomas Caton**, not Alfred. The actual census scan was inspected on 9 September 2026.

Source: 1830 U.S. census, Ohio County, Virginia, p. 209, row 22; NARA microfilm M19, roll 198, digitized by Internet Archive. [Names/ages, image n423](https://archive.org/details/populationsc18300198unit/page/n423/mode/1up); [continuation/totals, image n424](https://archive.org/details/populationsc18300198unit/page/n424/mode/1up).

| Recorded category | Count |
| --- | ---: |
| Free white males aged 5–9 | 1 |
| Free white males aged 30–39 | 1 |
| Free white females under 5 | 1 |
| Free white females aged 30–39 | 1 |
| Every other age/sex category | 0 |
| Household total on continuation page | 4 |

**Interpretation:** Aaron’s reported birth of 16 May 1820 makes him 10 on the census reference date, 1 June 1830. There is NO male aged 10–14 in this household. The 5–9 boy is an imperfect candidate, requiring an error in the age category or reported birth date before he could be identified as Aaron. Neither error is established. The census does not name anyone but the head or specify relationships among members.

The adult male’s age is consistent with Thomas being born approximately 1790–1800, assuming it represents the named head. Do not merge him with the Thomas who died in Washington County, Pennsylvania by 1795. The page is grouped under C surnames; adjacent names are not reliable evidence of immediate neighbors.

**Next:** identify Thomas in Ohio/Marshall County tax, deed, probate, and later census records; determine the boy’s identity independently. Obtaining page 209 is complete, but identifying Aaron’s parents is not.

---

## 12. Aaron's possible children

Known:
- William Bramwell Caton, b. 1847 Delaware County, Ohio

Compiled leads requiring confirmation:
- Nancy Roseman Caton, b. c.1849, d. 1865
- twins Levi Andrew Caton and Aaron Nathan Caton, b. 25 Nov 1853, died 1854

These names may be useful for:
- locating the 1850/1860 family
- identifying naming patterns
- cemetery/church records
- matching Gardner or Caton relatives

Do not treat them as confirmed until independent records are found.

---

## 13. Current hypothesis ranking

### Tier 1 — pursue aggressively
**George W. Caton, Virginia-born Missouri tailor, as close relative of Aaron**
- unusually strong occupational/geographic similarity
- exact relationship unknown
- could be brother, half-brother, uncle, cousin, or (chronologically) young father
- need George W.'s parentage and evidence of association with Aaron

**Thomas Caton, 1830 Ohio County household**
- image obtained; see section 11
- no male aged 10–14; boy aged 5–9 does not exactly match Aaron
- trace Thomas rather than repeat page acquisition

**Aaron 1850/1860 census**
- should expose migration timing, children and neighbor network

### Tier 2
**Thomas + Susanna → George Caton of Washington County, PA**
- independently documented
- plausible upper-Ohio ancestral network
- no bridge to Aaron yet

**Alfred Caton**
- highly plausible close relative based on Wheeling/Belmont geography and Missouri migration
- parentage still unproven

**Elizabeth Caton Gosney**
- adult Caton in Ohio County immediately before Aaron's birth
- relationship unknown

**Joseph Caton, Missouri tailor**
- occupational cluster is intriguing
- identity/origin still needed

### Tier 3
**David Caton of Harrison County, VA**
- Aaron fits 1820 household age structure
- no connective evidence yet

**Older Theophilus / Muskingum cluster**
- genuine PA→Ohio Caton family
- no bridge yet

---

## 14. Highest-value next actions

Work these in roughly this order:

1. **Trace Thomas Caton identified on 1830 Ohio County p. 209**
   - image acquisition and household transcription COMPLETE
   - identify his spouse and children through independent records
   - investigate tax/deed/probate and 1840/1850 records, allowing for Marshall County formation

2. **Find Aaron in 1850 and 1860**
   - search variant/misindexed surnames
   - use wife Sarah, son William, occupation tailor, Ohio→Missouri migration

3. **Prove George W. Caton the Missouri tailor's parentage**
   - obituary, probate, marriage record, children's death records, biographies
   - distinguish him from George Wesley Caton of Muskingum County

4. **Trace Joseph Caton, pioneer tailor of Brunswick**
   - census, obituary, death, probate
   - establish birthplace and parents
   - test kinship with George W./Aaron

5. **Pull Aaron's complete Civil War service file**
   - NARA RG 94
   - Missouri Union Volunteers
   - M405
   - inspect enlistment papers, consent, birthplace/residence/age/occupation/next-of-kin clues

6. **Pull Susanna Caton's 1825 Washington County, PA probate**
   - determine heirs/grandchildren

7. **Trace Elizabeth Caton Gosney**
   - 1818 marriage bond
   - 1827 deed
   - later records

8. **Prove/disprove Alfred's parentage**
   - original 1828 marriage paperwork
   - obituary
   - children’s death records
   - probate in Montgomery/Lincoln/other correct county

9. **Muskingum George W. Caton Will Book D p.553**
   - obtain actual will and enumerate heirs/kin
   - useful mainly to separate/define the Ohio cluster

10. **Ohio County tax/deed/probate 1810–1840**
    - identify Caton adults around Aaron's birth and childhood

---

## 15. Research standard

Use a simple evidence hierarchy:

**A — Primary / near-primary**
- census image
- marriage bond/license
- probate/will
- deed
- military service record
- contemporary church/cemetery record
- death certificate
- contemporary newspaper

**B — Strong secondary**
- county history or biography based on identified subject/family
- scholarly/local-history publication with sources

**C — Lead only**
- FamilySearch collaborative tree
- Ancestry public tree
- WikiTree
- Find a Grave biography without cited records
- unsourced genealogy pages

Never convert a C-level relationship into the working tree without A/B corroboration.

For same-name men, separate by:
- age
- spouse
- occupation
- children
- county
- migration timeline

---

## 16. Parentage status (with latest census update)

**Aaron Caton's parents remain unknown.**

The research has, however, narrowed substantially:

- The old “George Thomas Caton + Jemima Prall VanKirk” parent theory for Alfred is now suspect and should not be propagated.
- A real Thomas + Susanna Caton family existed in Washington County, PA, with son George and collateral Prall/VanKirk marriages.
- A plausible David Caton household in Harrison County can accommodate infant Aaron in 1820, but has no later bridge.
- The strongest newly developed FAN-club lead is **George W. Caton, c.1800 Virginia, tailor, Washington D.C. → Missouri**, because Aaron shares Virginia origin, the unusual skilled occupation, and Missouri migration.
- A second Missouri Caton tailor, **Joseph Caton**, makes the occupational cluster more interesting.
- The **1830 Ohio County census page 209 is now obtained** (Thomas Caton; see section 11). Aaron’s **1850/1860 household** remains missing.

### Rule for future research
Do not spend tokens repeatedly summarizing all prior findings in chat. Keep this file as the canonical state. During research, report only genuinely new findings and their implications. When the thread becomes long, update this file and start a new thread with the latest version attached.


## 17. Earlier research pass — 9 September 2026 (historical log)

**Superseded where noted by section 18:** the Joseph biography and 1830 census images were subsequently obtained. Keep this section as a record of the first pass, not the current task list.

### New lead: Joseph Caton’s family
Search-index excerpts from a genealogy forum post identify Sue Caton, wife of James Monroe Dumm, as the daughter of Joseph and Harriet (Dumm) Caton. The excerpts describe Joseph as Virginia-born, a tailor in Brunswick, and subsequently living in Boonville. These are **C-level leads only**: the full post could not be opened, and its underlying biography has not been inspected. Do not promote these details to verified facts.

Source: [James Monroe Dumm 1852 MO + Sue Caton](https://www.support.genealogy.com/forum/surnames/topics/caton/1094/). Alternate host: https://www.genealogy.com/forum/surnames/topics/caton/1094/

A separate search result from a historical photograph catalog mentions James Dumm marrying Sue Caton in 1888. This may help locate the original family biography; it does not establish Joseph’s kinship to Aaron. Full catalog page was inaccessible.

Source: [Dumm family Old Place photographs, photo 2](https://boulderislandora.marmot.org/islandora/object/islandora%3A69377).

Next finite task: retrieve the James Monroe Dumm biography, identify its book/year/page, then trace Joseph with wife Harriet and daughter Sue in census and marriage records. Compare the claimed later Boonville residence with the earlier Salisbury claim; do not assume either is correct or that they conflict without dates.

### Corrections to inference
- Alfred was approximately 15 at Aaron’s birth, not biologically too young to be his father. Age alone cannot eliminate him.
- Shared surname, occupation, and state of birth justify investigating the Missouri tailors, but do not establish kinship or warrant ranking them above direct records of Aaron.
- Failure to locate Caton in an index does not establish absence from Ohio County: spelling, indexing, and residence in another surname’s household remain possibilities.

### Access and outcome
- Did not obtain the 1830 Ohio County page 209 image or identify the head.
- Did not locate a verified Aaron household in 1850 or 1860.
- Did not recover missing source URLs from earlier conversation context.
- Several targeted searches returned irrelevant results; direct attempts to open the genealogy forum pages returned errors. These are access/search limitations, not negative genealogical evidence.
- No new parent-child relationship proven.


## 18. Second research pass — 9 September 2026: sources obtained

### A. Thomas Caton, 1830 census
Completed the highest-priority finite task. See section 11 for exact transcription, image references, and limits. Both sides of page 209 were inspected. This is primary evidence of Thomas’s household, not evidence naming Aaron’s father.

### B. Joseph Caton — published family biography located
**Source:** *Portrait and biographical record of Denver and vicinity, Colorado* (Chicago: Chapman Publishing Co., 1898), James Monroe Dumm biography, pp. 658–659; relevant Caton paragraph on p. 659. [Scan, p. 659](https://archive.org/download/biographportrait00chaprich/page/n702.jpg). This is a contemporary family biography (B-level), not a vital record; its informant is not identified in the passage.

It identifies Sue Caton, wife of James Monroe Dumm, as a Brunswick native and daughter of Joseph and Harriet (Dumm) Caton. Joseph was born in Virginia, worked as a tailor in Brunswick, and was living in Booneville [book spelling] at publication. Harriet was born in Ohio and died in Brunswick. Five of six children reached maturity:

| Child | Detail in the 1898 biography |
| --- | --- |
| Eugene DeCourcey Caton | Eldest son; Civil War drummer boy; nicknamed Harry; resident of New Frankford, Missouri |
| Thomas Edgar Caton | Operating lead mines in Galena, Kansas |
| Otis O. Caton | Merchant tailor in Salisbury, Missouri |
| Sallie Caton Shantz | Resident of Marshall, Missouri |
| Sue Caton Dumm | Wife of James Monroe Dumm; Brunswick-born |

The biography makes a generalized claim of an old Virginia family and Revolutionary War service. It names no Revolutionary ancestor: **do not infer a lineage from this claim**. The passage gives neither Joseph’s birth date nor his parents and does not mention Aaron.

**Implication:** the evidence establishes tailoring within Joseph’s own family (Joseph and Otis), with specific children useful for census and death-record searches. It does not connect this family to Aaron or George W. Caton.

### C. Joseph’s early occupation independently located in county histories
- *History of Howard and Chariton Counties, Missouri* (1883), p. 441, names Joseph Winters and Joseph Caton as Brunswick’s first tailors. OCR inspected. [Book](https://archive.org/details/historyofhowardc01nati/page/441/mode/1up).
- *Historical, pictorial and biographical record, of Chariton County, Missouri* (Salisbury: Pictorial and Biographical Publishing Co., 1896), p. 232, identifies Joseph Caton as Brunswick’s pioneer tailor and then a Salisbury citizen. [Scan](https://archive.org/download/historicalpictor00sali/page/n329.jpg).
- These histories may share material and should not be counted as wholly independent accounts. The 1896 Salisbury and 1898 Booneville statements could reflect a move; no conflict or move is proven from the two statements alone.

### D. Ohio County marriage transcription: Sarah Caton / John Patten
The [pre-1836 groom index](https://www.wvgw.net/ohio/mar1836g.txt) records:
- Alfred Caton / Sarah Cheadick — 23 January 1828.
- Alexander Gosney / Elizabeth Caton — 17 December 1818 (duplicate entry spells bride Caon).
- **John Patten / Sarah Caton — 30 November 1831.**

This is a derivative transcription. Its introduction says dates may be marriage dates OR registration dates, with originals in the Ohio County Clerk’s Office and collections in the Wheeling Room of the Ohio County Library. Preserve that qualification. Do not silently normalize the surname Cheadick to Chaddock without inspecting the original.

Sarah is a newly isolated local Caton woman. Her age, prior marital status, and relationship to Thomas, Alfred, Elizabeth, or Aaron are unknown. The index does not establish that she was a widow or a daughter of any candidate household. Retrieve the original Patten–Caton marriage paperwork for bondsman, consent, marital-status, and residence clues.

### E. Limited negative results
A literal spelling search of the published pre-1836 groom index did not locate Thomas Caton (searched Caton/Catton/Caten/Cayton). The published Ohio County will index through 1835 did not return those variants either. This does not exclude him: neither index covers every record type or later period, and transcription errors remain possible.

### F. Next work — specific, unresolved
1. Find Aaron, Sarah, and William in 1850 and 1860; identifying their household remains more direct than speculative collateral matches.
2. Trace **Thomas Caton, male 30–39 in Ohio County in 1830**, using 1830s tax/deeds and 1840/1850 census records; account for places later in Marshall County. Identify his children before fitting Aaron to the household.
3. Obtain original **John Patten–Sarah Caton, 30 November 1831** paperwork; identify Sarah independently.
4. Trace Joseph and Harriet using **Eugene DeCourcey/Harry, Thomas Edgar, Otis O., Sallie Shantz, and Sue Dumm**. Census ages and children’s death records may establish Joseph’s precise Virginia origin and generation.
5. Continue Aaron’s military/pension records and the existing probate leads when accessible. No application or certificate number has yet been recovered.

### G. Reproducible source access
The public Internet Archive metadata and download endpoints were accessible with ordinary unauthenticated HTTP requests even when the web-page reader failed. No login or access restriction was bypassed. The 1830 reel identifier is `populationsc18300198unit`; p. 209 is image n423 (names/ages) and n424 (continuation). The images use `/download/IDENTIFIER/page/nNUMBER.jpg`. This download endpoint counts accessible images, which can differ from the leaf numbers in page metadata or the book reader. Verified download indices: census p. 209 = n423/n424; Denver biography p. 659 = n702; Chariton history p. 232 = n329. Always inspect the printed page.

An evidence ZIP accompanies this handoff with the inspected census scans, relevant biography scans, and a source manifest. The original source publications are public-domain historical material. No family-tree merge was made.
